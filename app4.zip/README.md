# LMS for E2E
Performance School of Real Estate.

### Application Setup:
1. `git clone`
2. `composer install`
3. `npm install`
4. `php artisan migrate`
5. `php artisan db:seed`
6. `php artisan serve`
7. `npm run watch`